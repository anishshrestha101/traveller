<?php
namespace ElementsKit;

defined( 'ABSPATH' ) || exit;

/**
 * Global helper class.
 *
 * @since 1.0.0
 */

class Utils extends \ElementsKit_Lite\Utils {
	//
}
