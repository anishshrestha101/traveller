<div class="attr-modal attr-fade ekit-wid-con" id="elementskit_go_pro_modal" tabindex="-1" role="dialog" aria-labelledby="elementskit_go_pro_modalLabel" style="display: none;">
	<div class="attr-modal-dialog attr-modal-dialog-centered ekit-go-pro-con" role="document">
        <div class="attr-modal-content">
        <button type="button" class="close attr-hidden" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <div class="attr-modal-body attr-text-center">
                <i class="icon icon-information"></i>
                <h2>Go Premium</h2>
                <p>Purchase our <a href="https://go.wpmet.com/ekitpro">pro version</a> to unlock these premium features!</p>
            </div>
        </div>
	</div>
</div>